import Header from '../components/Header'

export default function SweepstakesPage() {
  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Sweepstakes</h1>
        {/* Content */}
      </main>
    </>
  )
} 
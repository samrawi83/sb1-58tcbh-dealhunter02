export async function getFeaturedDeals() {
  // Placeholder data - replace with actual API call
  return {
    featured: [
      {
        id: 1,
        title: 'Sample Deal 1',
        description: 'This is a sample deal',
        image: '/placeholder.jpg'
      },
      {
        id: 2,
        title: 'Sample Deal 2',
        description: 'This is another sample deal',
        image: '/placeholder.jpg'
      }
    ]
  }
} 
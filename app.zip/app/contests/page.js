import Header from '../components/Header'

export default function ContestsPage() {
  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Contests</h1>
        {/* Content */}
      </main>
    </>
  )
} 
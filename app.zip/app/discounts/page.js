import Header from '../components/Header'

export default function DiscountsPage() {
  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Discounts</h1>
        {/* Content */}
      </main>
    </>
  )
} 